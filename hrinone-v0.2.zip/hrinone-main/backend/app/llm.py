"""Optional LLM access (Anthropic Messages API) using only the standard library.

Set ANTHROPIC_API_KEY to switch it on; without a key every caller falls back to the offline
rule-based answer, so the app always works. Callers must only send data the model needs
(see pseudonymise in routers/analytics.py) and must wrap untrusted text in tags.
"""
import json
import os
import urllib.request

API_URL = "https://api.anthropic.com/v1/messages"


def available() -> bool:
    return bool(os.getenv("ANTHROPIC_API_KEY"))


def complete(system: str, user: str, max_tokens: int = 500, timeout: int = 25) -> str | None:
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        return None
    body = {
        "model": os.getenv("HRINONE_MODEL", "claude-sonnet-4-6"),
        "max_tokens": max_tokens,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }
    req = urllib.request.Request(
        API_URL,
        data=json.dumps(body).encode(),
        headers={"content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as res:
            data = json.load(res)
        text = "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text").strip()
        return text or None
    except Exception:
        return None  # never break the feature because the model is unreachable
